import UStorage from './core/UStorage';

console.log(UStorage);