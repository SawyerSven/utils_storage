/* 公共的interface */
