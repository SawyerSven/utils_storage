export type basics = number | string | boolean;

export type expires = number | Date; 