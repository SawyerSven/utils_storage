import UlocalStorage from './localStorage';
class UStorage {
    constructor(commonPrefix) {
        this.local = new UlocalStorage();
    }
}
export default UStorage;
