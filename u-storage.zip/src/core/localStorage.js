import { toParseJson } from '../utils/index';
class UlocalStorage {
    constructor() {
        this.data = window.localStorage;
    }
    add(key, value, expires) {
        let res = this.data.setItem(key, value);
        return {
            code: 200,
            target: value,
            message: 'success'
        };
    }
    search(key) {
        if (this.data.getItem(key)) {
            return String(this.data.getItem(key));
        }
        return `not found this localStorage named ${key}`;
    }
    remove(key) {
        if (this.data.getItem(key)) {
            let target = toParseJson(this.data.getItem(key));
            this.data.removeItem(key);
            return {
                code: 200,
                target,
                message: 'success'
            };
        }
        return {
            code: 404,
            target: key,
            message: `not found target localStorage named ${key}`
        };
    }
}
export default UlocalStorage;
